# Contributing

Contributions should preserve the medical boundary: no diagnosis, no prescribing,
no unsafe emergency substitution, no hidden network calls, and no personally
identifiable data in test fixtures.

New guideline packs must include source name, jurisdiction, date checked, support
scope, and downgrade conditions. When guideline conflicts exist, preserve the conflict
instead of forcing a single answer.
