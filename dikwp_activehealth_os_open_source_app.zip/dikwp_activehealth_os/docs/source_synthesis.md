# Source Synthesis

DIKWP ActiveHealth OS is shaped by several source streams.

1. Energy and information foundations: information processing has energy cost, and intelligent systems should manage energy, attention, and semantic value rather than maximize raw data.
2. DIKWP and intent foundations: proactive health requires a purpose layer, because data and knowledge alone do not define the patient's future-oriented health direction.
3. DIKWP-Mesh discipline: evidence, prior, residual, reliability, Kill/Recovery, and action boundary must be explicit.
4. Life-centered consciousness boundary: health systems must respect homeostasis, feeling, embodiment, and welfare without pretending that ordinary software memory or recommendations equal consciousness.
5. Public-health orientation: primary health care, universal access, preventive care, and people-centred digital health motivate the product direction.
