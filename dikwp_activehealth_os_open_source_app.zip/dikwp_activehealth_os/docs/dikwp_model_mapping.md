# DIKWP Model Mapping for Active Health

| Layer | Health meaning | Example |
|---|---|---|
| D / Data | Self-reported symptoms, age, vitals, habits, barriers | `age=52`, `bmi=27.5`, fatigue |
| I / Information | Patterns and relationships | age-based screening, access barriers, chronic follow-up gap |
| K / Knowledge | Public-health and clinical knowledge references | preventive-care prompts, red-flag warnings |
| W / Wisdom | Safety, equity, privacy, harm boundaries | do not diagnose, urgent escalation, low-cost access |
| P / Purpose | Patient's health goals and constraints | avoid stroke, reduce cost, understand screenings |
| R / Reliability | Source strength, unknowns, Kill/Recovery | self-report provisional, clinician review required |

DIKWP ActiveHealth OS treats personal health as a **purpose-bound, evidence-bound, privacy-bound ledger**, not as a raw-data optimization problem.
