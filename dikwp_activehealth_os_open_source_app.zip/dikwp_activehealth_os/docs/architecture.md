# Architecture

DIKWP ActiveHealth OS is an offline-first proactive medicine navigation layer.

## Pipeline

1. **Profile ingestion**: self-reported health profile JSON.
2. **Red flag boundary**: emergency warning-sign scan.
3. **Preventive prompt builder**: age/risk/local-guideline dependent discussion prompts.
4. **DIKWP health ledger**: Data, Information, Knowledge, Wisdom, Purpose, Reliability.
5. **Equity layer**: cost, language, transport, disability, digital-access barriers.
6. **Privacy ledger**: consent, data minimization, sharing boundaries.
7. **Clinician handoff**: safe note for human review.
8. **Community queue**: outreach priority without diagnosis.

## Design principle

The system turns unstructured health concern into **better questions and safer next steps**, not into automated diagnosis.
