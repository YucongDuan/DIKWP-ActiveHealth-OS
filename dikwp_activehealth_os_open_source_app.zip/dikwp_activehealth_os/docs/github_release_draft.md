# GitHub Release Draft

Title: DIKWP ActiveHealth OS v0.1.0 — Open-source proactive medicine navigation for everyone

This first release provides an offline-first proactive health navigation prototype. It turns self-reported profile data into a DIKWP health ledger, red-flag boundary, preventive-care discussion plan, privacy ledger, clinician handoff note, and community outreach queue.

This project is not a diagnosis tool or medical device. It is designed to improve preparation, prevention, equity, and clinician communication.

Highlights:

- CLI and optional local Streamlit dashboard.
- Synthetic examples.
- Static boundary audit.
- MIT license and DIKWP attribution.
