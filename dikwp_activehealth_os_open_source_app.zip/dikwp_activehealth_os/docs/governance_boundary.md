# Governance Boundary

DIKWP ActiveHealth OS must not be used to:

- diagnose diseases;
- prescribe medications;
- override clinician judgment;
- replace emergency medical services;
- deny care or triage people away from care;
- profile or discriminate against people;
- store protected health information without safeguards;
- claim regulatory approval or medical-device status;
- interpret labs or imaging as final medical conclusions;
- optimize for cost reduction by suppressing care.

Safe use means: education, navigation, preparation, reminders, consent, equity, evidence custody, clinician handoff, and urgent boundary escalation.
