# Integration Guide

## Low-resource deployment

Run the CLI on a local laptop, clinic workstation, school health office, or community center computer. No cloud service is required.

## Possible integrations

- FHIR/SMART-on-FHIR profile import and export.
- Local preventive guideline packs.
- Community resource directories.
- Clinician review workflow.
- Translation Integrity layer for multilingual health handoffs.
- ProofLedger OS for claim-to-evidence validation.
- MemoryLedger OS for consented long-term health context.
- IntentGuard OS for safe agentic workflows.

## Production requirements

Production health deployments require encryption, access controls, retention policy, clinician governance, jurisdiction-specific privacy compliance, and medical-device regulatory assessment if risk level changes.
