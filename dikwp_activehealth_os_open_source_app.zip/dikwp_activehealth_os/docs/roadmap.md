# Roadmap

## v0.1

- Offline CLI and demo.
- Red-flag boundary.
- Preventive-care prompts.
- DIKWP health ledger.
- Clinician handoff and community queue.

## v0.2

- Multilingual templates.
- Jurisdiction-specific guideline packs.
- FHIR-compatible export skeleton.
- Accessibility-first interface.

## v0.3

- Local community resource matching.
- Shared decision-making cards.
- Clinician review workflow.
- Integration with ProofLedger and MemoryLedger.

## v1.0

- Validated community deployment pilot.
- Clinical governance board.
- External safety review.
- Formal privacy compliance pathway.
