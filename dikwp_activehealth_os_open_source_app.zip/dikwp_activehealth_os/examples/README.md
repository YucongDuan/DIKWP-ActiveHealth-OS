# Examples

The example profiles are synthetic and contain no real personal health information.
