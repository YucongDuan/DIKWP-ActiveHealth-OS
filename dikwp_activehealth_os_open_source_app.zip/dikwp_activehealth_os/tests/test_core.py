from dikwp_activehealth.analyzer import analyze_profile
from dikwp_activehealth.static_audit import audit_path


def test_red_flag_escalation():
    profile = {
        "user": {"age": 60, "sex_at_birth": "male", "location_country": "local"},
        "symptoms": ["chest pain with shortness of breath"],
        "known_conditions": [],
        "vitals": {},
        "habits": {},
        "goals": [],
        "barriers": [],
    }
    report = analyze_profile(profile)
    assert report.decision.level == "urgent_escalation"
    assert report.red_flags


def test_preventive_prompts_for_midlife_profile():
    profile = {
        "user": {"age": 52, "sex_at_birth": "female", "has_cervix": True, "location_country": "local"},
        "symptoms": ["no acute symptoms"],
        "known_conditions": ["hypertension"],
        "vitals": {"bmi": 27.5},
        "habits": {"tobacco": "no"},
        "goals": ["prevention"],
        "barriers": ["cost"],
    }
    report = analyze_profile(profile)
    topics = {item["topic"] for item in report.preventive_items}
    assert "blood_pressure" in topics
    assert "colorectal_cancer_screening" in topics
    assert "chronic_condition_followup" in topics
    assert report.privacy_consent_ledger["data_minimization"]


def test_static_audit_passes_source():
    result = audit_path("src")
    assert result["pass"] is True
