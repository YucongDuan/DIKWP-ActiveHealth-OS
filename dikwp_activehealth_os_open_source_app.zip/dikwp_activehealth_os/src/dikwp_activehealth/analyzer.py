from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any, Dict, List

from .dikwp import build_dikwp_record
from .models import Decision, EvidenceItem, HealthReport
from .preventive import preventive_plan
from .privacy import build_privacy_consent_ledger, equity_notes
from .redflags import detect_red_flags
from .reports import clinician_handoff_markdown, recommendations_markdown
from .text_utils import safe_int

SYSTEM_NAME = "DIKWP ActiveHealth OS"
VERSION = "0.1.0"
MEDICAL_BOUNDARY = "Education and navigation only: no diagnosis, no prescribing, no emergency care replacement, no medical-device claim."


def load_json(path: str | Path) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def analyze_profile(profile: Dict[str, Any]) -> HealthReport:
    red_flags, red_reasons = detect_red_flags(profile)
    preventive_items = preventive_plan(profile)
    access_notes = equity_notes(profile)
    age = safe_int(profile.get("user", {}).get("age"), 0)
    missing: List[str] = []
    for field in ["age", "location_country"]:
        if field not in profile.get("user", {}):
            missing.append(f"Missing user.{field}; recommendations are less reliable.")
    if "symptoms" not in profile:
        missing.append("Missing symptoms list; red-flag scan may be incomplete.")
    if "known_conditions" not in profile:
        missing.append("Missing known_conditions; chronic follow-up prompts may be incomplete.")
    if age <= 0:
        missing.append("Age unknown or invalid; age-based preventive prompts are downgraded.")

    if red_flags:
        decision = Decision("urgent_escalation", 1.0, red_reasons, "Seek local emergency or urgent medical care now; do not rely on this tool for triage.")
    else:
        high_priority = [x for x in preventive_items if x["priority"] == "high"]
        score = min(0.85, 0.25 + 0.10 * len(high_priority) + 0.05 * len(access_notes) + 0.02 * len(preventive_items))
        if high_priority:
            decision = Decision("clinician_review_recommended", score, [f"{len(high_priority)} high-priority preventive/follow-up prompts."], "Prepare clinician handoff and schedule appropriate care.")
        else:
            decision = Decision("routine_prevention_plan", score, ["No emergency warning sign detected from provided text."], "Use preventive-care conversation plan and update missing data.")

    dikwp = build_dikwp_record(profile, red_flags, preventive_items, decision.level)
    evidence_ledger = [
        EvidenceItem("self_reported_profile", "User/SelfReport", "Supports only the existence of reported symptoms, goals, barriers, and history.", "Provisional", "Self-report can be incomplete or inaccurate."),
        EvidenceItem("public_health_preventive_guidelines", "Guideline", "Supports general preventive-care discussion prompts; local jurisdiction and personal risk may differ.", "Borrowed", "Use qualified clinician and current local guideline review."),
        EvidenceItem("CDC/official emergency warning sign pages", "PublicHealth", "Supports emergency warning-sign escalation language.", "Borrowed", "Not a diagnosis."),
    ]
    residuals = missing + [
        "No physical exam, labs, imaging, medication reconciliation, or clinician judgment included.",
        "Guidelines vary by country, risk group, prior diagnoses, pregnancy status, and patient preference.",
        "Social determinants and affordability may be underreported.",
    ]
    kill_conditions = [
        "Any red-flag symptom is reported or worsens.",
        "User is pregnant with severe symptoms or reports bleeding, seizure, severe headache, or vision changes.",
        "Self-harm crisis language appears.",
        "Clinician determines a different risk level.",
        "Profile data is outdated, incomplete, or belongs to another person without consent.",
    ]
    recovery_actions = [
        "Escalate urgent warning signs to local emergency services or urgent care.",
        "Bring clinician handoff note, medication list, measurements, questions, and barriers to appointment.",
        "Update profile after clinician feedback; preserve residuals and guideline conflicts.",
        "Use local community resources for cost, language, transport, and digital-access barriers.",
    ]
    return HealthReport(
        system=SYSTEM_NAME,
        version=VERSION,
        medical_boundary=MEDICAL_BOUNDARY,
        decision=decision,
        red_flags=red_flags,
        preventive_items=preventive_items,
        dikwp_record=dikwp,
        evidence_ledger=evidence_ledger,
        residuals=residuals,
        kill_conditions=kill_conditions,
        recovery_actions=recovery_actions,
        equity_notes=access_notes,
        privacy_consent_ledger=build_privacy_consent_ledger(profile),
    )


def write_outputs(report: HealthReport, profile: Dict[str, Any], out_dir: str | Path) -> None:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    report_dict = report.to_dict()
    (out / "activehealth_report.json").write_text(json.dumps(report_dict, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "preventive_plan.json").write_text(json.dumps(report_dict["preventive_items"], ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "privacy_consent_ledger.json").write_text(json.dumps(report_dict["privacy_consent_ledger"], ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "clinician_handoff.md").write_text(clinician_handoff_markdown(report, profile), encoding="utf-8")
    (out / "recommendations.md").write_text(recommendations_markdown(report), encoding="utf-8")


def analyze_file(path: str | Path, out_dir: str | Path) -> HealthReport:
    profile = load_json(path)
    report = analyze_profile(profile)
    write_outputs(report, profile, out_dir)
    return report


def batch_analyze(path: str | Path, out_dir: str | Path) -> List[HealthReport]:
    data = load_json(path)
    profiles = data.get("profiles", [])
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    reports = [analyze_profile(p) for p in profiles]
    rows = []
    for p, r in zip(profiles, reports):
        rows.append({
            "profile_id": p.get("profile_id", "unknown"),
            "decision_level": r.decision.level,
            "score": f"{r.decision.score:.3f}",
            "red_flag_count": len(r.red_flags),
            "preventive_item_count": len(r.preventive_items),
            "top_action": r.decision.action,
        })
    with open(out / "community_outreach_queue.csv", "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()) if rows else ["profile_id"])
        writer.writeheader()
        for row in sorted(rows, key=lambda x: (x["decision_level"] != "urgent_escalation", -float(x["score"]))):
            writer.writerow(row)
    (out / "community_batch_report.json").write_text(json.dumps([r.to_dict() for r in reports], ensure_ascii=False, indent=2), encoding="utf-8")
    return reports
