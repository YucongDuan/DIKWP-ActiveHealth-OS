from __future__ import annotations

import json

from .analyzer import analyze_profile


def main() -> None:
    import streamlit as st
    st.set_page_config(page_title="DIKWP ActiveHealth OS", layout="wide")
    st.title("DIKWP ActiveHealth OS")
    st.caption("Education and proactive health navigation only; not a diagnosis or medical device.")
    raw = st.text_area("Paste health profile JSON", height=360)
    if st.button("Analyze") and raw.strip():
        profile = json.loads(raw)
        report = analyze_profile(profile)
        st.subheader("Decision")
        st.json(report.decision.__dict__)
        st.subheader("Preventive Items")
        st.json(report.preventive_items)
        st.subheader("Residuals")
        st.write(report.residuals)


if __name__ == "__main__":
    main()
