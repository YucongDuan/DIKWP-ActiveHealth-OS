from __future__ import annotations

from typing import Any, Dict, List

from .text_utils import safe_int, safe_float, normalize_text


def preventive_plan(profile: Dict[str, Any]) -> List[Dict[str, Any]]:
    user = profile.get("user", {})
    habits = profile.get("habits", {})
    known = [normalize_text(x) for x in profile.get("known_conditions", [])]
    age = safe_int(user.get("age"), 0)
    sex_at_birth = normalize_text(user.get("sex_at_birth", ""))
    has_cervix = bool(user.get("has_cervix", sex_at_birth == "female"))
    pregnant = bool(user.get("pregnant", False))
    bmi = safe_float(profile.get("vitals", {}).get("bmi"), 0.0)
    tobacco = normalize_text(habits.get("tobacco", ""))
    items: List[Dict[str, Any]] = []

    def add(topic: str, prompt: str, priority: str, source: str, boundary: str = "Discuss with a qualified clinician under local guidelines.") -> None:
        items.append({
            "topic": topic,
            "priority": priority,
            "prompt": prompt,
            "boundary": boundary,
            "source_reference": source,
            "reliability": "Borrowed / guideline-dependent",
        })

    if age >= 18:
        add("blood_pressure", "Ask whether your blood pressure has been measured recently and whether follow-up is needed.", "routine", "USPSTF / local preventive care")
        add("mental_health_screening", "Ask whether depression, anxiety, sleep, stress, and substance-use screening is appropriate.", "routine", "USPSTF / local preventive care")

    if 40 <= age <= 74 and sex_at_birth in {"female", "afab", ""}:
        add("breast_cancer_screening", "Ask about breast cancer screening options and interval for your risk profile.", "routine", "USPSTF breast cancer screening")

    if has_cervix and 21 <= age <= 65:
        add("cervical_cancer_screening", "Ask whether cervical cancer screening is due, and which test interval fits local guidelines.", "routine", "local cervical cancer screening guideline")

    if 45 <= age <= 75:
        add("colorectal_cancer_screening", "Ask which colorectal cancer screening option is appropriate and accessible.", "routine", "USPSTF colorectal cancer screening")

    if 35 <= age <= 70 and bmi >= 25:
        add("diabetes_screening", "Ask whether diabetes or prediabetes screening is appropriate, especially with overweight/obesity or family history.", "routine", "USPSTF diabetes screening")

    if "current" in tobacco or "yes" in tobacco or "smoke" in tobacco:
        add("tobacco_cessation", "Ask for evidence-based tobacco cessation support and low-cost options.", "high", "USPSTF tobacco cessation")

    if pregnant:
        add("prenatal_care", "Schedule or confirm prenatal care and discuss warning signs, nutrition, immunizations, and follow-up.", "high", "local prenatal care guideline")

    if "hypertension" in known or "diabetes" in known or "asthma" in known:
        add("chronic_condition_followup", "Prepare medication list, home measurements, symptoms, barriers, and questions for chronic-condition follow-up.", "high", "clinical care team")

    add("vaccination_review", "Ask whether seasonal and age-appropriate immunizations are due under local guidance.", "routine", "local immunization guidance")
    add("oral_and_vision_care", "Ask about affordable dental and vision care options if access has been delayed.", "routine", "local primary/community care")

    return items
