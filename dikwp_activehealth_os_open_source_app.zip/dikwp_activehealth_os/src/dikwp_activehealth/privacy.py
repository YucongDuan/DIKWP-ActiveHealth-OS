from __future__ import annotations

from typing import Any, Dict, List


def build_privacy_consent_ledger(profile: Dict[str, Any]) -> Dict[str, Any]:
    consent = profile.get("consent", {})
    return {
        "data_minimization": "Store only fields needed for proactive navigation and handoff; remove direct identifiers from public outputs.",
        "consent_status": {
            "store_local_report": bool(consent.get("store_local_report", True)),
            "share_with_clinician": bool(consent.get("share_with_clinician", False)),
            "share_with_community_worker": bool(consent.get("share_with_community_worker", False)),
        },
        "sensitive_fields_policy": "Credentials, exact addresses, government IDs, raw images, and unrelated family data should not be stored in this prototype.",
        "deletion_instruction": "Delete output folder to remove generated local records. Production deployments require access control, encryption, audit logs, and DSAR workflow.",
    }


def equity_notes(profile: Dict[str, Any]) -> List[str]:
    barriers = [str(x).lower() for x in profile.get("barriers", [])]
    notes: List[str] = []
    if any("cost" in x or "insurance" in x or "money" in x for x in barriers):
        notes.append("Cost/insurance barrier reported: prioritize low-cost clinics, community programs, generic options discussion, and social work referral if available.")
    if any("language" in x or "translation" in x for x in barriers):
        notes.append("Language barrier reported: request interpreter support and translated handoff materials.")
    if any("transport" in x or "rural" in x or "distance" in x for x in barriers):
        notes.append("Transportation or rural-access barrier reported: consider telehealth, community clinics, mobile screening, or bundled appointments.")
    if any("disability" in x or "mobility" in x for x in barriers):
        notes.append("Disability or mobility barrier reported: request accessible appointment logistics and caregiver-supported planning if consented.")
    if not notes:
        notes.append("No explicit access barrier provided; still verify cost, language, transport, disability, and digital-access constraints.")
    return notes
