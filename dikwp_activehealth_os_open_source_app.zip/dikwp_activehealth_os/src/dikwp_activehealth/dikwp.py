from __future__ import annotations

from typing import Any, Dict, List

from .models import DIKWPRecord


def build_dikwp_record(profile: Dict[str, Any], red_flags: List[str], preventive_items: List[Dict[str, Any]], decision_level: str) -> DIKWPRecord:
    user = profile.get("user", {})
    barriers = profile.get("barriers", [])
    goals = profile.get("goals", [])
    evidence_notes = profile.get("evidence_notes", [])

    data = {
        "self_reported_user_fields": sorted(user.keys()),
        "symptom_count": len(profile.get("symptoms", [])),
        "known_condition_count": len(profile.get("known_conditions", [])),
        "vitals_fields": sorted(profile.get("vitals", {}).keys()),
        "barriers": barriers,
    }
    information = {
        "red_flag_count": len(red_flags),
        "preventive_gap_count": len(preventive_items),
        "access_barrier_count": len(barriers),
        "decision_level": decision_level,
    }
    knowledge = [
        "Primary-care and preventive-care navigation is safer when it preserves evidence, uncertainty, and local guideline dependency.",
        "Red-flag symptoms require urgent/emergency routing rather than app-based diagnosis.",
        "Preventive-care reminders should be discussed with qualified clinicians under local guidelines.",
    ]
    wisdom = [
        "Do not diagnose or prescribe from self-reported data.",
        "Escalate urgent warning signs rather than optimizing convenience.",
        "Preserve privacy and consent; minimize data retention.",
        "Treat cost, language, disability, rurality, and access barriers as health variables, not side notes.",
    ]
    purpose = {
        "local_goal": "Improve readiness for preventive care, earlier help-seeking, and clinician communication.",
        "user_goals": goals,
        "constraints": ["no diagnosis", "no prescribing", "local clinical review", "privacy-first"],
        "feedback": "Use clinician feedback and outcomes to update the plan; do not self-escalate beyond scope.",
    }
    reliability = {
        "self_report_reliability": "Provisional",
        "guideline_reliability": "Borrowed / jurisdiction-dependent",
        "clinical_decision_reliability": "Blocked: requires qualified clinician",
        "residual_policy": "Unknowns are preserved as questions rather than converted into false certainty.",
        "evidence_notes": evidence_notes,
    }
    return DIKWPRecord(data, information, knowledge, wisdom, purpose, reliability)
