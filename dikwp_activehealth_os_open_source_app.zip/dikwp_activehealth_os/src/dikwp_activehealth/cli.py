from __future__ import annotations

import argparse
import json
from pathlib import Path

from .analyzer import analyze_file, batch_analyze
from .static_audit import write_audit


def main() -> None:
    parser = argparse.ArgumentParser(prog="activehealth", description="DIKWP proactive medicine navigation layer")
    sub = parser.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("analyze")
    a.add_argument("profile")
    a.add_argument("--out", default="outputs/demo")

    b = sub.add_parser("batch")
    b.add_argument("profiles")
    b.add_argument("--out", default="outputs/demo")

    s = sub.add_parser("static-audit")
    s.add_argument("path")
    s.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")

    args = parser.parse_args()
    if args.cmd == "analyze":
        report = analyze_file(args.profile, args.out)
        print(json.dumps({"decision": report.decision.level, "score": report.decision.score, "red_flags": report.red_flags}, ensure_ascii=False, indent=2))
    elif args.cmd == "batch":
        reports = batch_analyze(args.profiles, args.out)
        print(json.dumps({"profile_count": len(reports), "urgent_count": sum(1 for r in reports if r.decision.level == "urgent_escalation")}, indent=2))
    elif args.cmd == "static-audit":
        result = write_audit(args.path, args.out)
        print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
