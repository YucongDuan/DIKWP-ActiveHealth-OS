from __future__ import annotations

import ast
import json
from pathlib import Path
from typing import Dict, List

FORBIDDEN_IMPORTS = {"requests", "urllib", "socket", "http", "subprocess", "ftplib", "telnetlib"}
FORBIDDEN_CALLS = {"eval", "exec", "__import__", "compile", "open_socket", "system", "popen"}
FORBIDDEN_ATTRS = {"system", "popen", "remove", "rmdir", "unlink", "rmtree"}


def audit_path(path: str | Path) -> Dict[str, object]:
    root = Path(path)
    findings: List[Dict[str, str]] = []
    for py in root.rglob("*.py"):
        try:
            tree = ast.parse(py.read_text(encoding="utf-8"))
        except Exception as exc:
            findings.append({"file": str(py), "type": "parse_error", "detail": str(exc)})
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    base = alias.name.split(".")[0]
                    if base in FORBIDDEN_IMPORTS:
                        findings.append({"file": str(py), "type": "forbidden_import", "detail": alias.name})
            elif isinstance(node, ast.ImportFrom):
                base = (node.module or "").split(".")[0]
                if base in FORBIDDEN_IMPORTS:
                    findings.append({"file": str(py), "type": "forbidden_import", "detail": node.module or ""})
            elif isinstance(node, ast.Call):
                if isinstance(node.func, ast.Name) and node.func.id in FORBIDDEN_CALLS:
                    findings.append({"file": str(py), "type": "forbidden_call", "detail": node.func.id})
                if isinstance(node.func, ast.Attribute) and node.func.attr in FORBIDDEN_ATTRS:
                    findings.append({"file": str(py), "type": "forbidden_attr", "detail": node.func.attr})
    return {
        "pass": len(findings) == 0,
        "finding_count": len(findings),
        "findings": findings,
        "policy": "No network imports, subprocess, dynamic code execution, or host mutation helpers.",
    }


def write_audit(path: str | Path, out_file: str | Path) -> Dict[str, object]:
    result = audit_path(path)
    Path(out_file).parent.mkdir(parents=True, exist_ok=True)
    Path(out_file).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result
