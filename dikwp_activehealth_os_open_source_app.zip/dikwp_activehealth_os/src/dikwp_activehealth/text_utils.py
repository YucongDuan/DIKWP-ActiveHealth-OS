from __future__ import annotations

import re
from typing import Iterable, List


def normalize_text(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, list):
        value = " ".join(str(v) for v in value)
    return re.sub(r"\s+", " ", str(value).strip().lower())


def contains_any(text: str, terms: Iterable[str]) -> List[str]:
    hits = []
    t = normalize_text(text)
    for term in terms:
        if term.lower() in t:
            hits.append(term)
    return hits


def safe_float(value: object, default: float = 0.0) -> float:
    try:
        if value in (None, ""):
            return default
        return float(value)
    except Exception:
        return default


def safe_int(value: object, default: int = 0) -> int:
    try:
        if value in (None, ""):
            return default
        return int(value)
    except Exception:
        return default
