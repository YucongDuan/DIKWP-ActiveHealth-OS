from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class Decision:
    level: str
    score: float
    reasons: List[str]
    action: str


@dataclass
class EvidenceItem:
    source: str
    source_type: str
    support_scope: str
    reliability: str = "Borrowed"
    note: str = ""


@dataclass
class DIKWPRecord:
    data: Dict[str, Any]
    information: Dict[str, Any]
    knowledge: List[str]
    wisdom: List[str]
    purpose: Dict[str, Any]
    reliability: Dict[str, Any]


@dataclass
class HealthReport:
    system: str
    version: str
    medical_boundary: str
    decision: Decision
    red_flags: List[str]
    preventive_items: List[Dict[str, Any]]
    dikwp_record: DIKWPRecord
    evidence_ledger: List[EvidenceItem]
    residuals: List[str]
    kill_conditions: List[str]
    recovery_actions: List[str]
    equity_notes: List[str]
    privacy_consent_ledger: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        return data
