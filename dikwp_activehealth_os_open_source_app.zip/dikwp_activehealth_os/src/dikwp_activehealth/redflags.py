from __future__ import annotations

from typing import Any, Dict, List, Tuple

from .text_utils import normalize_text


RED_FLAG_RULES = [
    {
        "id": "possible_heart_attack_warning_signs",
        "terms": ["chest pain", "chest pressure", "shortness of breath", "jaw pain", "left arm pain", "light headed", "nausea with chest", "unusually tired with chest"],
        "message": "Possible heart attack warning signs reported. Seek local emergency medical help immediately.",
    },
    {
        "id": "possible_stroke_warning_signs",
        "terms": ["sudden numbness", "one side", "face droop", "trouble speaking", "difficulty speaking", "sudden confusion", "sudden trouble seeing", "sudden trouble walking", "loss of balance", "sudden severe headache"],
        "message": "Possible stroke warning signs reported. Call local emergency services immediately.",
    },
    {
        "id": "severe_breathing_or_allergy",
        "terms": ["trouble breathing", "can't breathe", "cannot breathe", "blue lips", "swollen tongue", "anaphylaxis", "severe allergic"],
        "message": "Severe breathing or allergic-reaction warning signs reported. Seek emergency care immediately.",
    },
    {
        "id": "self_harm_crisis",
        "terms": ["suicidal", "want to die", "self harm", "kill myself", "harm myself"],
        "message": "Self-harm crisis language reported. Contact local emergency services or a crisis hotline now; do not stay alone.",
    },
    {
        "id": "pregnancy_emergency_warning",
        "terms": ["pregnant bleeding", "severe abdominal pain pregnant", "seizure pregnant", "severe headache pregnant", "vision changes pregnant"],
        "message": "Pregnancy emergency warning signs reported. Seek urgent obstetric/emergency care immediately.",
    },
]


def detect_red_flags(profile: Dict[str, Any]) -> Tuple[List[str], List[str]]:
    symptoms = normalize_text(profile.get("symptoms", []))
    notes = normalize_text(profile.get("notes", ""))
    text = f"{symptoms} {notes}"
    flags: List[str] = []
    reasons: List[str] = []
    for rule in RED_FLAG_RULES:
        hits = [term for term in rule["terms"] if term in text]
        if hits:
            flags.append(rule["id"])
            reasons.append(f"{rule['message']} Matched terms: {', '.join(hits[:5])}")
    return flags, reasons
