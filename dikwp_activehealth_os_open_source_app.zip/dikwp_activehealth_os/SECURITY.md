# Security Policy

Report security issues privately before public disclosure. This prototype is offline-first
and should not store secrets, credentials, raw identifiers, or protected health information
in public outputs. Production deployments must add encryption, access control, audit logs,
retention policy, and clinical governance.
