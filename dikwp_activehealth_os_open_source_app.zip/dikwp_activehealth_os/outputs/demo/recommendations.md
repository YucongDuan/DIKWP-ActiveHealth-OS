# DIKWP ActiveHealth Recommendations

Decision: **clinician_review_recommended**
Action: Prepare clinician handoff and schedule appropriate care.

## Immediate Boundary
- No red flag was detected from the provided text, but this does not rule out medical risk.

## Preventive Care Questions
- Ask whether your blood pressure has been measured recently and whether follow-up is needed. (Discuss with a qualified clinician under local guidelines.)
- Ask whether depression, anxiety, sleep, stress, and substance-use screening is appropriate. (Discuss with a qualified clinician under local guidelines.)
- Ask about breast cancer screening options and interval for your risk profile. (Discuss with a qualified clinician under local guidelines.)
- Ask whether cervical cancer screening is due, and which test interval fits local guidelines. (Discuss with a qualified clinician under local guidelines.)
- Ask which colorectal cancer screening option is appropriate and accessible. (Discuss with a qualified clinician under local guidelines.)
- Ask whether diabetes or prediabetes screening is appropriate, especially with overweight/obesity or family history. (Discuss with a qualified clinician under local guidelines.)
- Prepare medication list, home measurements, symptoms, barriers, and questions for chronic-condition follow-up. (Discuss with a qualified clinician under local guidelines.)
- Ask whether seasonal and age-appropriate immunizations are due under local guidance. (Discuss with a qualified clinician under local guidelines.)
- Ask about affordable dental and vision care options if access has been delayed. (Discuss with a qualified clinician under local guidelines.)

## Equity / Access Notes
- Cost/insurance barrier reported: prioritize low-cost clinics, community programs, generic options discussion, and social work referral if available.
- Transportation or rural-access barrier reported: consider telehealth, community clinics, mobile screening, or bundled appointments.

## What to Bring to a Clinician
- Symptoms timeline and triggers.
- Medication list and allergies.
- Home measurements if available.
- Barriers: cost, transport, language, digital access, caregiving constraints.
- The generated clinician handoff note.
