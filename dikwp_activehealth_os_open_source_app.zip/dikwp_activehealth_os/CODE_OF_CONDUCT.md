# Code of Conduct

Use this project to improve access, understanding, safety, and clinician-patient
communication. Do not use it to replace clinicians, deny care, discriminate, or
profile people unfairly.
